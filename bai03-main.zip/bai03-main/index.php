<?php
	$a=5;	
	echo $a;
?><!--1p17-->
<br>
<?php
	$a3 = 	5;
	echo $a3;
?><!--2p15-->
<br>
<?php
	$a = 5;
	$A = 10;
	echo $a;
	echo '<br>';
	echo $A
?><!--3p39-->
<br>
<?php
	define('PI', 3.14);
	echo PI;
?><!--5p48-->
<br>
<?php
	$str = "Hello World";
	echo $str;
?><!--6p58-->
<br>
<?php
	$firstName = 'Le Ha';
	$lastName = 'Quoc Thinh';
	$fullName = $firstName . ' '. $lastName;
	echo $fullName;
?><!--8p25-->
